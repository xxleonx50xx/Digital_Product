# layout-sample-furry-box
this is just a simple sample of a layout build from a previus desing.

[first version on adobe XD](https://xd.adobe.com/spec/2c9c033b-9245-42a1-495d-4ed75543bc3f-5aad/)

[demo on his first version] (https://durbonca.github.io/layout-sample-furry-box/)


